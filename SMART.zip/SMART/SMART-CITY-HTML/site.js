'use strict';
const menu=document.querySelector('#menu-toggle');
menu.onclick=()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));document.querySelector('#public-nav').classList.toggle('open',open);};
document.querySelectorAll('#public-nav a').forEach(a=>a.onclick=()=>{menu.setAttribute('aria-expanded','false');document.querySelector('#public-nav').classList.remove('open');});
const loginForm=document.querySelector('#login-form');
document.querySelector('#app-screen .skip').onclick=e=>{e.preventDefault();document.querySelector('#main').focus();};
const password=document.querySelector('#password');
const toggle=document.querySelector('#password-toggle');
toggle.onclick=()=>{const show=password.type==='password';password.type=show?'text':'password';toggle.textContent=show?'Fshih':'Shfaq';toggle.setAttribute('aria-pressed',String(show));};
loginForm.onsubmit=async e=>{
  e.preventDefault();const button=loginForm.querySelector('[type="submit"]'),error=document.querySelector('#login-error');
  button.disabled=true;error.textContent='';
  try{await City.login(document.querySelector('#email').value,password.value);password.value='';const next=location.hash.split('/')[1];location.hash='app/'+(['transport','eco','energy','report'].includes(next)?next:'dashboard');}
  catch(e){error.textContent=e.message;}finally{button.disabled=false;}
};
window.Router=(()=>{
  let started=false,routeNumber=0;
  async function show(){
    const turn=++routeNumber,hash=location.hash.slice(1),page=hash.split('/')[1]||'dashboard';
    let screen=hash.startsWith('app/')||hash==='main'?'app':hash.startsWith('login')?'login':'public';
    if(screen==='app'){
      try{await City.init();}catch(e){document.querySelector('#login-error').textContent=e.message;location.hash='login/'+page;screen='login';}
    }
    if(turn!==routeNumber)return;
    for(const name of ['public','login','app'])document.querySelector('#'+name+'-screen').hidden=name!==screen;
    document.body.className=screen==='app'?'workspace-body':screen==='login'?'login-page':'';
    if(screen==='app'){
      if(!started){App.init();started=true;}App.render(page);
    }else{
      document.querySelector('#settings').close();
      document.title=screen==='login'?'Hyr në llogari — Smart City':'Smart City — Më afër qytetit tënd';
    }
    if(hash==='home'||hash.startsWith('login')||hash.startsWith('app/'))window.scrollTo(0,0);
  }
  window.addEventListener('hashchange',show);
  window.addEventListener('pageshow',e=>{if(e.persisted)show();});
  return {show};
})();
Router.show();
