// Version statik: hyrja është demonstrative dhe ruajtja bëhet në shfletues.
window.City = (() => {
  'use strict';
  const DATA = 'smartcity.static.data.v1';
  const ACCOUNT = 'smartcity.static.account.v1';
  const SESSION = 'smartcity.static.session.v1';
  const email = 'qytetar@smartcity.al';
  let state, user, status = '', queue = Promise.resolve();
  const empty = () => ({version:1,trips:[],eco:[],energy:[],reports:[],settings:{rate:.12,currency:'EUR'}});
  const number = (v,min,max) => {const n=Number(v);if(String(v).trim()===''||!Number.isFinite(n)||n<min||n>max)throw Error(`Shkruaj një numër nga ${min} deri në ${max}.`);return n;};
  const text = (v,min=3,max=160) => {const s=String(v).trim();if(s.length<min||s.length>max)throw Error(`Teksti duhet të ketë ${min}–${max} karaktere.`);return s;};
  const escape = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt = (n,d=1) => new Intl.NumberFormat('sq-AL',{maximumFractionDigits:d}).format(n);
  const money = n => new Intl.NumberFormat('sq-AL',{minimumFractionDigits:2,maximumFractionDigits:2}).format(n)+' €';
  const when = s => {const d=new Date(s),pad=n=>String(n).padStart(2,'0');return `${pad(d.getDate())}.${pad(d.getMonth()+1)}.${d.getFullYear()}, ${pad(d.getHours())}:${pad(d.getMinutes())}`;};
  const sum = (rows,key) => rows.reduce((a,r)=>a+Number(r[key]||0),0);
  const record = data => ({id:crypto.randomUUID(),date:new Date().toISOString(),...data});
  const energy = (watts,hours,days,rate) => {const kwh=watts*hours*days/1000;return {kwh,cost:kwh*rate};};
  async function digest(value) {
    const buffer=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value));
    return Array.from(new Uint8Array(buffer),b=>b.toString(16).padStart(2,'0')).join('');
  }
  async function account() {
    const saved=localStorage.getItem(ACCOUNT);
    if(saved)return JSON.parse(saved);
    const value={email,name:'Qytetar Smart City',hash:await digest('SmartCity2026!')};
    localStorage.setItem(ACCOUNT,JSON.stringify(value));
    return value;
  }
  async function login(address,password) {
    try {
      const a=await account();
      if(address.trim().toLowerCase()!==a.email||await digest(password)!==a.hash)throw Error('Email-i ose fjalëkalimi nuk është i saktë.');
      sessionStorage.setItem(SESSION,JSON.stringify({expires:Date.now()+43200000}));
      user={email:a.email,name:a.name};
    } catch(e) {if(e.name==='SecurityError')throw Error('Lejo ruajtjen në shfletues për ta përdorur aplikacionin.');throw e;}
  }
  async function checkSession() {
    const saved=JSON.parse(sessionStorage.getItem(SESSION)||'null');
    if(!saved||saved.expires<=Date.now()){user=undefined;throw Error('Hyr në llogari për të vazhduar.');}
    const a=await account();user={email:a.email,name:a.name};return {user};
  }
  async function init() {
    await checkSession();
    try {
      const saved=localStorage.getItem(DATA);
      state=saved?JSON.parse(saved):empty();
      if(state.version!==1||!state.settings||['trips','eco','energy','reports'].some(k=>!Array.isArray(state[k])))throw Error();
    } catch {throw Error('Regjistrimet lokale nuk mund të lexohen. Përdor një profil tjetër të shfletuesit.');}
  }
  function update(fn) {
    const task=queue.then(async()=>{
      await checkSession();const next=structuredClone(state);fn(next);
      try {localStorage.setItem(DATA,JSON.stringify(next));state=next;status='';}
      catch {status='Ruajtja nuk u krye. Kontrollo hapësirën dhe lejet e shfletuesit.';throw Error(status);}
    });
    queue=task.catch(()=>{});return task;
  }
  function replace(next) {return update(s=>{for(const k of Object.keys(s))delete s[k];Object.assign(s,next);});}
  async function accountAction(action,options={}) {
    await checkSession();
    if(action==='logout'){sessionStorage.removeItem(SESSION);user=undefined;state=undefined;return {ok:true};}
    if(action==='password'){
      const input=JSON.parse(options.body),a=await account();
      if(await digest(input.currentPassword)!==a.hash)throw Error('Fjalëkalimi aktual nuk është i saktë.');
      if(input.newPassword.length<12||input.newPassword.length>128)throw Error('Fjalëkalimi i ri duhet të ketë 12–128 karaktere.');
      if(input.newPassword===input.currentPassword)throw Error('Zgjidh një fjalëkalim të ndryshëm.');
      a.hash=await digest(input.newPassword);localStorage.setItem(ACCOUNT,JSON.stringify(a));
      sessionStorage.removeItem(SESSION);user=undefined;return {ok:true};
    }
    throw Error('Veprim i panjohur.');
  }
  function stats() {return {trips:state.trips.length,fare:sum(state.trips,'fare'),points:sum(state.eco,'points'),eco:state.eco.length,kwh:sum(state.energy,'kwh'),cost:sum(state.energy,'cost'),reports:state.reports.length,resolved:state.reports.filter(r=>r.status==='Zgjidhur').length};}
  return {empty,number,text,escape,fmt,money,when,sum,record,energy,login,init,accountAction,checkSession,update,replace,stats,get state(){return state;},get user(){return user;},get storageError(){return status;}};
})();
