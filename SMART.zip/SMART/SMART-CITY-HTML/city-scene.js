// Qyteti vizatohet me SVG: kontrollet ndryshojnë vetëm pamjen publike.
(() => {
  'use strict';
  const defaults = {scene:'night', trees:0, led:false, mode:'Taksi'};
  let draft = {...defaults}, paused = false;
  const comparison = 100;
  try { const value=JSON.parse(localStorage.getItem('smartcity.visual.v1')||'null');
    if(value && ['night','day','rain','traffic'].includes(value.scene)) draft={...defaults,scene:value.scene,trees:Math.max(0,Math.min(20,Math.floor(Number(value.trees)||0))),led:value.led===true};
  } catch {}
  const points = (x,y,z=0) => [600+(x-y)*0.64,145+(x+y)*0.32-z];
  const polygon = list => list.map(p=>p.join(',')).join(' ');
  const p = (x,y,z=0) => points(x,y,z);
  const shape = (list,fill,extra='') => `<polygon points="${polygon(list)}" fill="${fill}" ${extra}/>`;

  function building(x,y,w,d,h,kind='glass') {
    const top=[p(x,y,h),p(x+w,y,h),p(x+w,y+d,h),p(x,y+d,h)];
    let result=shape([p(x,y+d),p(x+w,y+d),p(x+w,y+d,h),p(x,y+d,h)],'url(#facade-left)','stroke="#b9e8ff33"')+shape([p(x+w,y),p(x+w,y+d),p(x+w,y+d,h),p(x+w,y,h)],'url(#facade-right)','stroke="#b9e8ff33"')+shape(top,kind==='solar'?'#80b4d1':'#7798b1','stroke="#c6eaff77"');
    for(let z=12;z<h-8;z+=15)for(let i=7;i<w-5;i+=12){result+=shape([p(x+i,y+d+.2,z),p(x+i+4,y+d+.2,z),p(x+i+4,y+d+.2,z+6),p(x+i,y+d+.2,z+6)],(i+z)%3?'#94dcff':'#e2eece','class="building-window"');}
    for(let z=12;z<h-8;z+=15)for(let i=7;i<d-5;i+=12){result+=shape([p(x+w+.2,y+i,z),p(x+w+.2,y+i+4,z),p(x+w+.2,y+i+4,z+6),p(x+w+.2,y+i,z+6)],'#79bce1','class="building-window side-window"');}
    if(h>120){const a=p(x+w/2,y+d/2,h);result+=`<path d="M${a[0]} ${a[1]}v-26" stroke="#afdcf5"/><circle cx="${a[0]}" cy="${a[1]-26}" r="3" fill="#abf8df" class="beacon"/>`;}
    if(kind==='solar'){result+=shape([p(x+6,y+7,h+3),p(x+w-6,y+7,h+3),p(x+w-6,y+d-7,h+3),p(x+6,y+d-7,h+3)],'#163f67','stroke="#90c8ef" stroke-width="1.5"');}
    return `<g class="city-building">${result}</g>`;
  }
  function tree(x,y,size=1){const [a,b]=p(x,y);return `<g class="city-tree" transform="translate(${a} ${b}) scale(${size})"><ellipse cy="1" rx="15" ry="7" fill="#020b1d55"/><path d="M0 0v-20" stroke="#76a9a1" stroke-width="3"/><ellipse cy="-23" rx="12" ry="17" fill="#276e60"/><ellipse cx="-4" cy="-28" rx="9" ry="13" fill="#68b5a0"/><ellipse cx="-6" cy="-31" rx="4" ry="7" fill="#a3e7ba" opacity=".5"/></g>`;}
  function citySvg(){
    const road=(x,y,w,d,fill)=>shape([p(x,y),p(x+w,y),p(x+w,y+d),p(x,y+d)],fill);
    const blocks=[[60,60,65,65,95],[160,65,62,62,175],[65,175,68,65,70],[170,178,64,62,115],[365,50,65,70,200],[465,65,58,58,125],[370,170,60,65,95],[460,180,75,60,155],[65,360,65,60,65],[175,370,70,65,105],[70,465,60,55,45],[180,465,60,55,80],[385,370,65,55,40],[485,375,55,55,70]];
    const objects=blocks.map((r,i)=>({depth:r[0]+r[1]+(r[2]+r[3])/2,html:building(...r,i%4===0?'solar':'glass')}));
    for(const [x,y]of [[25,110],[30,245],[110,250],[250,80],[350,25],[570,160],[30,360],[345,430]])objects.push({depth:x+y,html:tree(x,y,.85)});
    const b=objects.sort((a,b)=>a.depth-b.depth).map(r=>r.html).join('');
    const roadA=[p(303,-10),p(303,610)],roadB=[p(-10,303),p(610,303)];
    const treeSpots=Array.from({length:20},(_,i)=>[370+(i%5)*39,455+Math.floor(i/5)*30]);
    return `<svg class="live-city-svg" viewBox="0 0 1200 650" role="img" aria-label="Qytet izometrik interaktiv me kulla, rrugë, mjete në lëvizje dhe park. Kontrollet poshtë ndryshojnë simulimin."><defs><linearGradient id="facade-left" x2=".8" y2="1"><stop stop-color="#537c9b"/><stop offset="1" stop-color="#183854"/></linearGradient><linearGradient id="facade-right" x2="0" y2="1"><stop stop-color="#2c526f"/><stop offset="1" stop-color="#0c233b"/></linearGradient><radialGradient id="city-glow"><stop stop-color="#5eafff" stop-opacity=".35"/><stop offset="1" stop-color="#23539c" stop-opacity="0"/></radialGradient><linearGradient id="island" x2="0" y2="1"><stop stop-color="#2b4e69"/><stop offset="1" stop-color="#0d2039"/></linearGradient><clipPath id="green-reveal"><rect id="reveal-rect" width="${1200*comparison/100}" height="650"/></clipPath><path id="avenue-a" d="M${roadA[0]}L${roadA[1]}"/><path id="avenue-b" d="M${roadB[0]}L${roadB[1]}"/></defs>
      <g class="stars">${Array.from({length:50},(_,i)=>`<circle cx="${(i*137+67)%1200}" cy="${(i*71)%430}" r="${i%3===0?1.3:.7}" fill="#c8e7ff" opacity="${.2+i%5*.13}"/>`).join('')}</g>
      <ellipse cx="630" cy="370" rx="570" ry="280" fill="url(#city-glow)"/>
      <g class="orbit-grid" fill="none" stroke="#83baff18"><ellipse cx="600" cy="390" rx="540" ry="210"/><ellipse cx="600" cy="390" rx="480" ry="170"/><path d="M55 390H1150M600 150V620"/></g>
      <ellipse cx="600" cy="550" rx="385" ry="48" fill="#000b1e" opacity=".65"/>
      ${shape([p(0,600),p(600,600),p(600,600,-26),p(0,600,-26)],'url(#island)')}${shape([p(600,0),p(600,600),p(600,600,-26),p(600,0,-26)],'#102e48')}
      ${road(0,0,600,600,'#274158')}${road(8,8,584,584,'#23394b')}
      ${road(278,0,50,600,'#0c1d31')}${road(0,278,600,50,'#0c1d31')}
      <g stroke="#adc9df66" stroke-width="1.5" stroke-dasharray="8 9"><path d="M${p(303,0)}L${p(303,600)}"/><path d="M${p(0,303)}L${p(600,303)}"/></g>
      ${road(270,0,5,600,'#7999aa')}${road(0,270,600,5,'#7999aa')}
      ${road(353,445,225,132,'#314f48')}
      <g clip-path="url(#green-reveal)" class="green-district">${road(353,445,225,132,'#3a735f')}${road(260,0,8,600,'#79ddc0')}${road(0,260,600,8,'#79ddc0')}${treeSpots.slice(0,draft.trees).map(([x,y])=>tree(x,y,1.1)).join('')}</g>
      ${b}
      <g class="streetlights" stroke="#caedff">${Array.from({length:8},(_,i)=>{const [x,y]=p(270,i*75+20);return `<path d="M${x} ${y}v-25l9 -5" stroke-width="1.5"/><ellipse cx="${x+9}" cy="${y-30}" rx="4" ry="2" fill="${draft.led?'#abfce2':'#ffe5a5'}" stroke="none"/><ellipse cx="${x+9}" cy="${y-5}" rx="21" ry="9" fill="${draft.led?'#abfce2':'#ffe5a5'}" opacity=".08"/>`;}).join('')}</g>
      <g class="moving-traffic">${Array.from({length:draft.scene==='traffic'?18:7},(_,i)=>`<g><rect x="-7" y="-4" width="${i===0&&draft.mode==='Autobus'?25:13}" height="7" rx="3" fill="${i===0?(draft.mode==='Biçikletë'?'#a3ffe0':'#d3f2ff'):i%3===0?'#f8b7a6':'#7c9ab9'}"/><circle cx="6" r="2" fill="#edfdff"/><animateMotion dur="${draft.scene==='traffic'?24:11+i%4*2}s" begin="-${i*2}s" repeatCount="indefinite"><mpath href="#avenue-${i%2?'b':'a'}"/></animateMotion></g>`).join('')}</g>
      <g class="rain-lines">${Array.from({length:65},(_,i)=>{let x=(i*97)%1200,y=(i*53)%650;return `<path d="M${x} ${y}l-6 19" style="animation-delay:-${i%8*.2}s"/>`;}).join('')}</g>
    </svg>`;
  }

  const host=document.querySelector('#interactive-city');
  const scenes={night:'Nata',day:'Dita',rain:'Shiu',traffic:'Trafiku'};
  host.innerHTML=`<div class="city-scene" id="city-scene"><div class="city-sky-symbol" aria-hidden="true"></div><div id="city-drawing"></div><div class="city-scene-label"><span>QYTETI NË LËVIZJE</span><button id="city-pause" type="button" aria-pressed="false" aria-label="Ndalo animacionet">Ⅱ</button></div></div><div class="city-controls"><div class="city-scene-buttons" role="group" aria-label="Zgjidh skenën e qytetit">${Object.entries(scenes).map(([id,label])=>`<button type="button" data-city-scene="${id}" aria-pressed="false">${{night:'◔',day:'☀',rain:'☂',traffic:'↗'}[id]} <span>${label}</span></button>`).join('')}</div><div class="city-park-controls"><label for="city-trees">Pemët në park <output id="city-tree-count">0 / 20</output><input id="city-trees" type="range" min="0" max="20" step="1" value="${draft.trees}"></label><button type="button" id="city-led" role="switch" aria-checked="false">ϟ LED</button></div><div class="city-control-bottom"><button type="button" id="city-green">✦ Qyteti i gjelbër</button><button type="button" id="city-reset">Rikthe pamjen ↺</button></div><p id="city-scene-status" role="status" aria-live="polite"></p></div>`;
  const scene=host.querySelector('#city-scene');
  function syncMotion(){
    const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
    const svg=host.querySelector('svg');
    if(paused||reduced)svg.pauseAnimations();else svg.unpauseAnimations();
    host.classList.toggle('scene-paused',paused||reduced);
    const button=host.querySelector('#city-pause');
    button.textContent=paused?'▷':'Ⅱ';button.setAttribute('aria-pressed',String(paused));
    button.setAttribute('aria-label',paused?'Nis animacionet':'Ndalo animacionet');
  }
  function refresh(){
    scene.dataset.scene=draft.scene;
    host.querySelector('#city-drawing').innerHTML=citySvg();
    host.querySelectorAll('[data-city-scene]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.cityScene===draft.scene)));
    host.querySelector('#city-trees').value=draft.trees;
    host.querySelector('#city-tree-count').textContent=draft.trees+' / 20';
    host.querySelector('#city-led').setAttribute('aria-checked',String(draft.led));
    host.querySelector('#city-scene-status').textContent=scenes[draft.scene]+' · '+draft.trees+' pemë të shtuara · '+(draft.led?'LED aktive':'Ndriçim klasik');
    syncMotion();
    try{localStorage.setItem('smartcity.visual.v1',JSON.stringify(draft));}catch{}
  }
  host.querySelectorAll('[data-city-scene]').forEach(button=>button.onclick=()=>{draft.scene=button.dataset.cityScene;refresh();});
  host.querySelector('#city-trees').oninput=event=>{draft.trees=Number(event.target.value);refresh();};
  host.querySelector('#city-led').onclick=()=>{draft.led=!draft.led;refresh();};
  host.querySelector('#city-green').onclick=()=>{draft={scene:'day',trees:12,led:true,mode:'Biçikletë'};refresh();};
  host.querySelector('#city-reset').onclick=()=>{draft={...defaults};paused=false;refresh();};
  host.querySelector('#city-pause').onclick=()=>{paused=!paused;syncMotion();};
  matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change',syncMotion);
  refresh();
})();
